# Name : Imtiaz Ahmed
# ID : 2013552642
# Course : CSE327

from flask import Flask, render_template, request, redirect, url_for, flash, session
from mock_data import generate_job_listings
from flask_sqlalchemy import SQLAlchemy

# setting the app
app = Flask(__name__, template_folder="templates", static_url_path='/static')

# database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)
app.secret_key = 'imtiaz ahmed'
app.static_folder = 'static'


# Job listing class


class JobListing(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_type = db.Column(db.String(50))
    industry = db.Column(db.String(50))
    country = db.Column(db.String(50))
    city = db.Column(db.String(50))
    remote = db.Column(db.String(50))
    salary = db.Column(db.Integer)
    experience = db.Column(db.Integer)
    posting_date = db.Column(db.Date)


# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)
    job_searches = db.relationship('JobSearch', backref='user', lazy=True)


# Job Search model
class JobSearch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_type = db.Column(db.String(50))
    industry = db.Column(db.String(50))
    country = db.Column(db.String(50))
    city = db.Column(db.String(50))
    remote = db.Column(db.String(50))
    min_salary = db.Column(db.Integer, nullable=True)
    max_salary = db.Column(db.Integer, nullable=True)
    experience = db.Column(db.String(50), nullable=True)
    posting_date = db.Column(db.String(50), nullable=True)

# homepage when i will write down the port, this page will come
@app.route('/')
def job_search():
    return render_template('index.html')


# check matching
def get_matching_job_listings(job_search):
    # Start with all job listings
    query = JobListing.query

    # Apply filters based on the job search preferences
    if job_search.job_type:
        query = query.filter(JobListing.job_type == job_search.job_type)
    if job_search.industry:
        query = query.filter(JobListing.industry == job_search.industry)
    if job_search.country:
        query = query.filter(JobListing.country == job_search.country)
    if job_search.city:
        query = query.filter(JobListing.city == job_search.city)
    if job_search.remote:
        query = query.filter(JobListing.remote == job_search.remote)
    if job_search.min_salary:
        query = query.filter(JobListing.salary >= job_search.min_salary)
    if job_search.max_salary:
        query = query.filter(JobListing.salary <= job_search.max_salary)
    if job_search.experience:
        query = query.filter(JobListing.experience == job_search.experience)
    if job_search.posting_date:
        query = query.filter(JobListing.posting_date == job_search.posting_date)

    # Execute the query and return the matching job listings
    matching_job_listings = query.all()
    return matching_job_listings


# when i will write down job_listings after the port no., this page will come

@app.route('/job_listings')
def job_listings():
    # Get the most recent job search for the current user
    job_search = JobSearch.query.filter_by(user_id=session['user_id']).order_by(JobSearch.id.desc()).first()

    # Get the matching job listings
    matching_job_listings = get_matching_job_listings(job_search)

    # Render the job listings page with the matching job listings
    return render_template('job_listings.html', job_listings=matching_job_listings)


# when i will write down job_preferences after the port no., this page will come


@app.route('/job_preferences')
def job_preferences():
    # Get all job searches for the current user
    job_searches = JobSearch.query.filter_by(user_id=session['user_id']).all()

    # Render the job preferences page with the job search data
    return render_template('job_preferences.html', job_searches=job_searches)



# main

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create the database tables
        # Create the predefined user if it doesn't exist
        user = User.query.filter_by(username='admin').first()
        if not user:
            user = User(username='admin', password='admin')
            db.session.add(user)
            db.session.commit()

        # Generate job listings and add them to the database only if they don't exist
        if JobListing.query.first() is None:
            job_listings = generate_job_listings(20)  # Generate 10 job listings
            for job_listing_data in job_listings:
                job_listing = JobListing(**job_listing_data)
                db.session.add(job_listing)
            db.session.commit()

    app.run(debug=True)
